</div>
</div>

<!-- JQuery script -->
<script src="js/jquery.min.js"></script>
<script src="js/jssocial/jssocials.min.js"></script>

<!--  page transition script script  -->
<script src="js/pagetransition/modernizr.custom.js"></script>
<script src="js/pagetransition/jquery.dlmenu.js"></script>
<script src="js/pagetransition/pagetransitions.js"></script>

<!--  page action & svg script  -->
<script src="js/pageaction.js"></script>
<script src="https://cdn.jsdelivr.net/npm/canvg/dist/browser/canvg.min.js"></script>
<script src="js/svgdrawing.js"></script>

<!--  video transition animation script  -->
<script src='js/zoarxj.js'></script>
<script src="js/footerinfo.js"></script> 


<!-- <script src="js/index.js"></script>  -->

</body>
</html>